import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public class Doctor extends Person {

	// ATRIBUTOS //

	
	String pass;
	LocalDate lastLog;
	String session;
	ArrayList<Xip> releaseList;
	
	
	// GETTERS & SETTERS //
	
	public String getPass() {
		return pass;
	}



	public void setPass(String pass) {
		this.pass = pass;
	}



	public LocalDate getLastLog() {
		return lastLog;
	}



	public void setLastLog(LocalDate lastLog) {
		this.lastLog = lastLog;
	}



	public String getSession() {
		return session;
	}



	public void setSession(String session) {
		this.session = session;
	}



	public ArrayList<Xip> getReleaseList() {
		return releaseList;
	}



	public void setReleaseList(ArrayList<Xip> releaseList) {
		this.releaseList = releaseList;
	}

	
	// CONSTRUCTORES //
	
	public Doctor() {
		
	}


	public Doctor(String pass, LocalDate lastLog, String session) {
		super();
		this.pass = pass;
		this.lastLog = lastLog;
		this.session = session;
	}

	// MÉTODOS //

	
	public void login(String mail, String pass) {
		/* Si el mail i el pass son correctes, 
		 * carrega a l’objecte els atributs de la BBDD a través del load(), 
		 * s’ha de fixar els atributs lastLog i el session a la BBDD.
		 */
		
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		// Query para comprobar que los datos coinciden
		try {
			String query = "SELECT * FROM doctor WHERE mail='"+mail+"' AND pass='"+pass+"';";
			System.out.println(query);

			ResultSet rs = db.getSt().executeQuery(query);
			
			if (rs.next()) {
				String dbmail = rs.getString("mail");
				String dbpass = rs.getString("pass");
				System.out.println(dbmail+" "+ dbpass);
				
				
				db.close();
				this.load(mail);
				
				//Generate session code
				RNG rng = new RNG();
				String sessionStr = "";
				for (int i=0;i<8;i++) {
					int sessionRNG = rng.generateRandomInt(10);
					sessionStr += sessionRNG;
				}
				
				System.out.println(sessionStr);
				
				//Generate LocalDate and session
				this.lastLog = LocalDate.now();
				
				this.session = sessionStr;
				
				//Update with lastLog and session code
				
				try {
					db.connectar();
					String update = "UPDATE doctor SET lastLog = '"+lastLog.toString()+"' , session = "+sessionStr+" WHERE mail ='"+mail+"'";
					System.out.println(update);
					db.getSt().executeUpdate(update);
					
					db.close();
				}
				
				catch (Exception e){
					System.out.println("Error al ejecutar el insert"+ e.getMessage());
				}
				
				
			}
			else {
				System.out.println("Ningun Doctor encontrado");
			}
			
			
		}
		catch (Exception e){
			System.out.println("Error al ejecutar la query"+ e.getMessage());
		}
		
		
		
		
	}
	
	public boolean isLogged(String mail, String session) {
		/* Retorna un boolean true si troba el mail
		 *  amb la session en data; carrega les dades amb login(). En cas contrari retorna false
		 */
		
		boolean logged = false;
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		
		try {
			String query = "SELECT * FROM doctor WHERE mail='"+mail+"' AND session = "+session;
			ResultSet rs = db.getSt().executeQuery(query);
			
			if (rs.next()) {
				String dblastLog = rs.getString("lastLog");
				System.out.println(dblastLog);
				
				LocalDate currentDate = LocalDate.now();
				
				
				// comprobar el dia actual
				
				if (currentDate.isEqual(LocalDate.parse(dblastLog))){
					logged = true;
				}
				
				
				db.close();
			}
			
			else {
				System.out.println("No se ha encontrado resultado en isLogged()");
			}
		}
		
		catch(SQLException e) {
			System.out.println("Error al ejecutar la query"+ e.getMessage());
		}
		
		System.out.println(logged);
		
		return logged;
		
	}
	
	public void loadReleaseList() {
		/* Carrega a l’array del Doctor tots els xips (que estan en data) de la BBDD vinculats a ell.
		 */
		this.releaseList = new ArrayList<Xip>();
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		
		try {
			String query = "SELECT * FROM `xip` WHERE doctor_mail = '"+this.mail+"' AND date > CURRENT_DATE();" ;
			ResultSet rs = db.getSt().executeQuery(query);
			System.out.println("Query Xips del docotor "+ query);

			
			while (rs.next()) {
				String dbId = rs.getString("id");
				String dbId_medicine = rs.getString("id_medicine");
				String dbId_patient = rs.getString("id_patient");
				String dbDate = rs.getString("date");
				
				
				//Crear objetos patient y medicine y loadearlos
				Patient pati = new Patient();
				pati.load(dbId_patient);
				
				Medicine med = new Medicine();
				med.load(Integer.parseInt(dbId_medicine));
				
				// Crear Objeto Xip y añadirle sus atributos y objetos
				
				Xip xip = new Xip(Integer.parseInt(dbId), med, pati, LocalDate.parse(dbDate));
				System.out.println("Añadir Xip");
				this.releaseList.add(xip);
				
			}
		}
		
		catch(SQLException e) {
			System.out.println("Error al ejecutar la query"+ e.getMessage());
		}
		db.close();
	}

	@Override
	public void load(String id) {
		/* Carrega a l’objecte les dades del Doctor que corresponen a id=(BBDD: farmacia.doctor.mail). */
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		
		try {
			String query = "SELECT * FROM doctor WHERE mail='"+id+"'";
			ResultSet rs = db.getSt().executeQuery(query);
			
			if (rs.next()) {
				String dbmail = rs.getString("mail");
				String dbpass = rs.getString("pass");
				String dbname = rs.getString("name");
				String dblastLog = rs.getString("lastLog");
				String dbsession = rs.getString("session");
				System.out.println(dbmail+" "+ dbpass);
				
				this.setMail(dbmail);
				this.setPass(dbpass);
				this.setName(dbname);
				this.setLastLog(LocalDate.parse(dblastLog));
				this.setSession(dbsession);
				
				System.out.println(this.mail);

				
				db.close();
			}
		}
		
		catch(SQLException e) {
			System.out.println("Error al ejecutar la query"+ e.getMessage());
		}
		
	}
	
	public String getTable() {
		/* Retorna un string que correspon a una taula HTML de tots els xips d’alta, vigents, del doctor.*/
		String table = "<tr>\n"
				+ "<th> ID </th>\n"
				+ "<th> Medicine </th>\n"
				+ "<th> Patient </th>\n"
				+ "<th> Expire Date </th>\n"
				+ "</tr>\n";
		System.out.println("For each Xip");

		for (Xip i : releaseList) {
			table += "<tr>\n"
					+ "<td>"+i.id+"</td>\n"
					+ "<td>"+i.medicine.name+"</td>\n"
					+ "<td>"+i.patient.name+"</td>\n"
					+ "<td>"+i.date.toString()+"</td>\n"
					+ "</tr>\n";
		}
		
		
		
		return table;
	}

}
