import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashGenerator {
    public static String generateMD5Hash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(input.getBytes());
            
            BigInteger hashBigInt = new BigInteger(1, hashBytes);
            String hash = hashBigInt.toString(16);
            
            while (hash.length() < 32) {
                hash = "0" + hash;
            }
            
            return hash;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        
        return null;
    }
}