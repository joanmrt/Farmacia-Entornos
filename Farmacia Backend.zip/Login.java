import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Login() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Llamar al metodo login de doctor con los parametros conseguidos
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		System.out.println(email + " "+ password);
		
		String hashpass = HashGenerator.generateMD5Hash(password);
		
		System.out.println(hashpass);
		
		Doctor doct = new Doctor();
		
		
		// Llamar funcion login
	
		doct.login(email, hashpass);
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().append(doct.getSession());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
