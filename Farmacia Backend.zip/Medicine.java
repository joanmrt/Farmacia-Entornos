import java.sql.ResultSet;
import java.sql.SQLException;

public class Medicine {

	// ATRIBUTS //
	
	int id;
	String name;
	float tmax;
	float tmin;
	
	// GETTERS & SETTERS //
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getTmax() {
		return tmax;
	}

	public void setTmax(float tmax) {
		this.tmax = tmax;
	}

	public float getTmin() {
		return tmin;
	}

	public void setTmin(float tmin) {
		this.tmin = tmin;
	}

	
	// CONSTRUCTORES //
	
	
	public Medicine() {
		
	}
	
	public Medicine(int id, String name, float tmax, float tmin) {
		super();
		this.id = id;
		this.name = name;
		this.tmax = tmax;
		this.tmin = tmin;
	}

	// METODOS //
	
	public void load(int id) {
		/*Carrega els atributs de la BBDD a l’objecte*/
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		
		try {
			String query = "SELECT * FROM medicine WHERE id="+id;
			ResultSet rs = db.getSt().executeQuery(query);
			System.out.println(query);
			
			if (rs.next()) {
				String dbId = rs.getString("id");
				String dbName = rs.getString("name");
				String dbTmax = rs.getString("tmax");
				String dbTmin = rs.getString("tmin");
				
				
				this.setId(Integer.parseInt(dbId));
				this.setName(dbName);
				this.setTmax(Float.parseFloat(dbTmax));
				this.setTmin(Float.parseFloat(dbTmin));
				
				db.close();
			}
		}
		
		catch(SQLException e) {
			System.out.println("Error al ejecutar la query"+ e.getMessage());
		}
	}
	
}
