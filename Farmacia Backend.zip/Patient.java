import java.sql.ResultSet;
import java.sql.SQLException;

public class Patient extends Person{

	
	// CONSTRUCTORES //
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Patient(String name, String mail) {
		super(name, mail);
		// TODO Auto-generated constructor stub
	}

	// METODOS //
	
	@Override
	public void load(String id) {
		// TODO Auto-generated method stub
		/* Carrega a l’objecte les dades del Doctor que corresponen a id=BBDD.doctor.mail. */
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		
		try {
			String query = "SELECT * FROM patient WHERE mail='"+id+"'";
			ResultSet rs = db.getSt().executeQuery(query);
			
			if (rs.next()) {
				String dbmail = rs.getString("mail");
				String name = rs.getString("name");
				
				
				this.setMail(dbmail);
				this.setName(name);
				
				db.close();
			}
		}
		
		catch(SQLException e) {
			System.out.println("Error al ejecutar la query"+ e.getMessage());
		}
	}

}
