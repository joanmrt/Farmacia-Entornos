import java.util.Random;

public class RNG {
    private Random random;

    public RNG() {
        random = new Random();
    }

    public int generateRandomInt(int bound) {
        return random.nextInt(bound);
    }
}