import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Release
 */
@WebServlet("/Release")
public class Release extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Release() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Recoger variables y añadirlas a la base de datos
		
		String email = request.getParameter("email");
		String session = request.getParameter("session");
		String xipid = request.getParameter("xipid");
		String patient = request.getParameter("patient");
		String medicine = request.getParameter("medicine");
		String limitDate = request.getParameter("limitdate");
		String respuesta = "Ha ocurrido un error";
		
		
		ConnectionDB db = new ConnectionDB();
		db.connectar();
		try {
			String insert = "INSERT INTO xip(id, doctor_mail, id_medicine, id_patient, date) VALUES ("+xipid+",'"+email+"',"+medicine+",'"+patient+"','"+limitDate+"')";
			System.out.println(insert);
			db.getSt().executeUpdate(insert);
			
			respuesta = "Información insertada correctamente";
		}

		catch(Exception e) {
			System.out.println("Insert fallido" +e.getMessage());
		}

		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().append(respuesta);
	}

}
