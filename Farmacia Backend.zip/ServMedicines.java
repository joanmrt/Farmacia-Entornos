

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONObject;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServMedicines
 */
@WebServlet("/ServMedicines")
public class ServMedicines extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ServMedicines() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//devolver codigo html de options para select de medicamentos
		
		String email = request.getParameter("email");
		String session = request.getParameter("session");
		Doctor doct = new Doctor();
		String jsonMedicine = null;
		JSONArray jsonArray = new JSONArray();
		
		// Consultar todos los pacientes asignados a un doctor
		
		if (doct.isLogged(email, session)) {
			
			ConnectionDB db = new ConnectionDB();
			db.connectar();
			
			try {
				String query = "SELECT * FROM medicine;";
				ResultSet rs = db.getSt().executeQuery(query);
				Class.forName("org.json.JSONObject");
				
				System.out.println("Query Medicines"+ query);

				
				while (rs.next()) {
					String dbId = rs.getString("id");
					String dbName = rs.getString("name");
					String dbTmin = rs.getString("tmin");
					String dbTmax = rs.getString("tmax");
					
					Medicine med = new Medicine(Integer.parseInt(dbId), dbName, Float.parseFloat(dbTmax), Float.parseFloat(dbTmin));
					JSONObject jsonObj = new JSONObject(med);
					jsonArray.put(jsonObj);
								
				}
				db.close();
			}
			
			catch(SQLException | ClassNotFoundException e) {
				System.out.println("Error al ejecutar la query"+ e.getMessage());
			}
			
		}
		
		jsonMedicine = jsonArray.toString();
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().append(jsonMedicine);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
