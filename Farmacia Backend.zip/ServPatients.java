import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.JSONArray;
import org.json.JSONObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServPatients
 */
@WebServlet("/ServPatients")
public class ServPatients extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ServPatients() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// devolver codigo html options para select de pacientes
		
		String email = request.getParameter("email");
		String session = request.getParameter("session");
		Doctor doct = new Doctor();
		String jsonPatients = null;
		JSONArray jsonArray = new JSONArray();
		
		// Consultar todos los pacientes asignados a un doctor
		
		if (doct.isLogged(email, session)) {
			
			ConnectionDB db = new ConnectionDB();
			db.connectar();
			
			try {
				String query = "SELECT * FROM patient;";
				ResultSet rs = db.getSt().executeQuery(query);
				System.out.println("Query Patients"+ query);
				Class.forName("org.json.JSONObject");

				
				while (rs.next()) {
					String dbId = rs.getString("mail");
					String dbName = rs.getString("name");
					
					Patient pati = new Patient(dbName, dbId);
					JSONObject jsonObj = new JSONObject(pati);
					jsonArray.put(jsonObj);
					
				}
				db.close();
			}
			
			catch(SQLException | ClassNotFoundException e) {
				System.out.println("Error al ejecutar la query"+ e.getMessage());
			}
			
		}
		
		jsonPatients = jsonArray.toString();
		
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().append(jsonPatients);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
