import java.time.LocalDate;

public class Xip {
	// ATRIBUTOS //
	
	int id;
	Medicine medicine;
	Patient patient;
	LocalDate date;
	
	// GETTERS & SETTERS //
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Medicine getMedicine() {
		return medicine;
	}

	public void setMedicine(Medicine medicine) {
		this.medicine = medicine;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	// CONSTRUCTORES //
	
	

	public Xip() {
		
	}
	
	public Xip(int id, Medicine medicine, Patient patient, LocalDate date) {
		
		this.id = id;
		this.medicine = medicine;
		this.patient = patient;
		this.date = date;
	}
	
	
	// METODOS //
	
	public void load(int id) {
		/*Carrega els atributs de la BBDD a l’objecte*/
		
	}
	
}