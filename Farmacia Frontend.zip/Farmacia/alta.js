function goToGestion() {
    window.location.href = "gestion.html";
}

function enviar() {
    let http = new XMLHttpRequest();

    let xipid = document.getElementById("xipid").value;
    let patient = document.getElementById("pacients").value;
    let medicine = document.getElementById("medicaments").value;
    let limitdate = document.getElementById("limitdate").value;
    let email = sessionStorage.getItem("email");
    let session = sessionStorage.getItem("session");

    http.open("POST", "http://localhost:3000/Farmaceutica/Release?email=" + email + "&session=" + session + "&xipid=" + xipid + "&patient=" + patient + "&medicine=" + medicine + "&limitdate=" + limitdate, true);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    http.send();

    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {

            document.getElementById("respuesta").innerHTML = http.responseText;
        }
    }
}

function getPatients() {

    let http = new XMLHttpRequest();

    let email = sessionStorage.getItem("email");
    let session = sessionStorage.getItem("session");

    http.open("GET", "http://localhost:3000/Farmaceutica/ServPatients?email=" + email + "&session=" + session, true);
    http.send();

    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            
            var jsonString = http.responseText;
            console.log(jsonString);
            var optionsArray = JSON.parse(jsonString);
            var select = document.getElementById("pacients");

            //Iterar por toda la array añadir option

            for (let i = 0; i < optionsArray.length; i++) {
                var option = optionsArray[i];

                var newOption = document.createElement("option");
                newOption.value = option.mail;
                newOption.text = option.name;

                select.appendChild(newOption);
            }

        }
    }

}

function getMedicines() {

    let http = new XMLHttpRequest();

    let email = sessionStorage.getItem("email");
    let session = sessionStorage.getItem("session");

    http.open("GET", "http://localhost:3000/Farmaceutica/ServMedicines?email=" + email + "&session=" + session, true);
    http.send();

    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {

            var jsonString = http.responseText;
            console.log(jsonString);
            var optionsArray = JSON.parse(jsonString);
            var select = document.getElementById("medicaments");

            //Iterar por toda la array añadir option

            for (let i = 0; i < optionsArray.length; i++) {
                var option = optionsArray[i];

                var newOption = document.createElement("option");
                newOption.value = option.id;
                newOption.text = option.name;

                select.appendChild(newOption);
            }
        }
    }
}


