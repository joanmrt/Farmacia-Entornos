function goToAlta(){
    window.location.href = "alta.html"
}

function logOut(){
    sessionStorage.removeItem("session");
    sessionStorage.removeItem("email");

    window.location.href = "login.html";
}

function getTable(){
    
    let http = new XMLHttpRequest();

    let email = sessionStorage.getItem("email");
    let session = sessionStorage.getItem("session");
    console.log(email, session);

    http.open("GET", "http://localhost:3000/Farmaceutica/ServXips?email="+email+"&session="+session, true);
    http.send();

    http.onreadystatechange=function(){
        if (this.readyState==4 && this.status==200){
            
        if (http.responseText == "null"){
            document.getElementById("tablaxips").innerHTML = "Session Expired";
        }
        else{
            document.getElementById("tablaxips").innerHTML = http.responseText;
        }
        
        }
    }
}