function checkUser() {
    let http = new XMLHttpRequest();

    let email = document.getElementById("email").value;
    let password = document.getElementById("pass").value;

    http.open("GET", "http://localhost:3000/Farmaceutica/Login?email=" + email + "&password=" + password, true);
    http.send();

    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {

            console.log(http.responseText);
            if (http.responseText == "null") {
                document.getElementById("resultado").innerHTML = "Email o contraseña incorrecta.";

            }

            else {
                sessionStorage.setItem("session", http.responseText);
                sessionStorage.setItem("email", email);

                window.location.href = "gestion.html"
            }

        }
    }
}

